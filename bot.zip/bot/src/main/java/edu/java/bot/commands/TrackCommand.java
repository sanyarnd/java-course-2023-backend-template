package edu.java.bot.commands;

import com.pengrad.telegrambot.model.Update;
import com.pengrad.telegrambot.request.SendMessage;
import edu.java.bot.utils.LinkStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.regex.Pattern;

@Component
public class TrackCommand implements Command {

    private final LinkStorageService linkStorageService;

    private final Pattern githubPattern = Pattern.compile("^https://github\\.com/.+/.+$");
    private final Pattern stackOverflowPattern = Pattern.compile("^https://stackoverflow\\.com/questions/.+$");

    public TrackCommand(LinkStorageService linkStorageService) {
        this.linkStorageService = linkStorageService;
    }

    @Override
    public String command() {
        return "/track";
    }

    @Override
    public String description() {
        return "Track a new link.";
    }

    @Override
    public SendMessage handle(Update update) {
        String messageText = update.message().text();
        String[] parts = messageText.split("\\s+", 2);
        if (parts.length < 2) {
            return new SendMessage(update.message().chat().id(), "Пожалуйста, укажите ссылку для отслеживания.");
        }

        String link = parts[1].trim();
        if (!isLinkValid(link)) {
            return new SendMessage(
                update.message().chat().id(),
                "Неправильный формат ссылки. Поддерживаются только ссылки на GitHub и StackOverflow."
            );
        }

        linkStorageService.addLink(update.message().from().id(), link);
        return new SendMessage(update.message().chat().id(), "Ссылка успешно добавлена для отслеживания.");
    }

    private boolean isLinkValid(String link) {
        return githubPattern.matcher(link).matches() || stackOverflowPattern.matcher(link).matches();
    }
}
