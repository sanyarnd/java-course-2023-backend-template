package edu.java.bot.commands;

import com.pengrad.telegrambot.model.Update;
import com.pengrad.telegrambot.request.SendMessage;
import edu.java.bot.utils.LinkStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.Set;
import java.util.StringJoiner;

@Component
public class ListCommand implements Command {

    private final LinkStorageService linkStorageService;

    public ListCommand(LinkStorageService linkStorageService) {
        this.linkStorageService = linkStorageService;
    }

    @Override
    public String command() {
        return "/list";
    }

    @Override
    public String description() {
        return "Вывести все отслеживаемые ссылки.";
    }

    @Override
    public SendMessage handle(Update update) {
        Long userId = update.message().from().id();
        Set<String> links = linkStorageService.getLinks(userId);

        if (links.isEmpty()) {
            return new SendMessage(update.message().chat().id(), "На данный момент вы не отслеживаете никакие ссылки.");
        } else {
            StringJoiner message = new StringJoiner("\n", "Ваши отслеживаемые ссылки:\n", "");
            links.forEach(message::add);
            return new SendMessage(update.message().chat().id(), message.toString());
        }
    }
}
