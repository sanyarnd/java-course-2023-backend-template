package edu.java.bot.commands;

import com.pengrad.telegrambot.model.Update;
import com.pengrad.telegrambot.request.SendMessage;
import org.springframework.stereotype.Component;

@Component
public class HelpCommand implements Command {

    @Override
    public String command() {
        return "/help";
    }

    @Override
    public String description() {
        return "Показать список доступных команд.";
    }

    @Override
    public SendMessage handle(Update update) {
        String responseText = "Доступные команды:\n" +
            "/start - Начать работу с ботом\n" +
            "/track - Начать отслеживание ссылки\n" +
            "/untrack - Прекратить отслеживание ссылки\n" +
            "/list - Показать список отслеживаемых ссылок";
        return new SendMessage(update.message().chat().id(), responseText);
    }
}
