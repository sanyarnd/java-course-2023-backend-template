package edu.java.bot.commands;

import com.pengrad.telegrambot.model.Update;
import com.pengrad.telegrambot.request.SendMessage;
import edu.java.bot.utils.LinkStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UntrackCommand implements Command {

    private final LinkStorageService linkStorageService;

    public UntrackCommand(LinkStorageService linkStorageService) {
        this.linkStorageService = linkStorageService;
    }

    @Override
    public String command() {
        return "/untrack";
    }

    @Override
    public String description() {
        return "Удалить указанную ссылку или все ссылки.";
    }

    @Override
    public SendMessage handle(Update update) {
        Long userId = update.message().from().id();
        String messageText = update.message().text();
        String[] parts = messageText.split("\\s+", 2);

        if (parts.length < 2) {
            return new SendMessage(update.message().chat().id(), "Пожалуйста, укажите ссылку или 'all' для удаления.");
        }

        String argument = parts[1].trim();
        if ("all".equals(argument)) {
            linkStorageService.removeAllLinks(userId);
            return new SendMessage(update.message().chat().id(), "Все ссылки удалены.");
        } else {
            boolean removed = linkStorageService.removeLink(userId, argument);
            if (removed) {
                return new SendMessage(update.message().chat().id(), "Ссылка успешно удалена.");
            } else {
                return new SendMessage(update.message().chat().id(), "Указанная ссылка не найдена.");
            }
        }
    }
}
