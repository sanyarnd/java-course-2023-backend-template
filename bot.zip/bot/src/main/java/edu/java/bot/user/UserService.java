package edu.java.bot.user;

import org.springframework.stereotype.Service;
import java.util.HashSet;
import java.util.Set;

@Service
public class UserService {
    private final Set<Long> registeredUsers = new HashSet<>();

    public boolean isRegistered(Long userId) {
        return registeredUsers.contains(userId);
    }

    public void registerUser(Long userId) {
        registeredUsers.add(userId);
    }
}
