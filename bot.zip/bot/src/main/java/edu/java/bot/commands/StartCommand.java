package edu.java.bot.commands;

import com.pengrad.telegrambot.model.Update;
import com.pengrad.telegrambot.request.SendMessage;
import edu.java.bot.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StartCommand implements Command {

    private final UserService userService;

    public StartCommand(UserService userService) {
        this.userService = userService;
    }

    @Override
    public String command() {
        return "/start";
    }

    @Override
    public String description() {
        return "Регестрация пользователя";
    }

    @Override
    public SendMessage handle(Update update) {
        Long userId = update.message().from().id();
        userService.registerUser(userId);
        return new SendMessage(
            update.message().chat().id(),
            "Вы успешно зарегистрированы. Теперь вы можете использовать все команды."
        );
    }
}
