package edu.java.bot.commands;

import com.pengrad.telegrambot.TelegramBot;
import com.pengrad.telegrambot.model.Update;
import com.pengrad.telegrambot.request.SendMessage;
import edu.java.bot.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CommandService {
    private final List<Command> commands;

    @Autowired
    public CommandService(List<Command> commands, UserService userService) {
        this.commands = commands;
        this.userService = userService;
    }

    private final UserService userService;

    public void processUpdate(Update update, TelegramBot bot) {
        if (update.message() != null && update.message().text() != null) {
            Long userId = update.message().from().id();
            boolean isRegistered = userService.isRegistered(userId);

            if (!isRegistered && !update.message().text().startsWith("/start")) {
                String responseText = "Пожалуйста, зарегистрируйтесь с помощью команды /start.";
                SendMessage request = new SendMessage(update.message().chat().id(), responseText);
                bot.execute(request);
                return;
            }

            commands.stream()
                .filter(command -> command.supports(update, userService))
                .findFirst()
                .ifPresentOrElse(command -> {
                    SendMessage request = command.handle(update);
                    bot.execute(request);
                }, () -> {
                    if (!isRegistered) {
                        SendMessage request = new SendMessage(
                            update.message().chat().id(),
                            "Команда не найдена. Для начала работы с ботом используйте /start."
                        );
                        bot.execute(request);
                    }
                });
        }
    }

}
