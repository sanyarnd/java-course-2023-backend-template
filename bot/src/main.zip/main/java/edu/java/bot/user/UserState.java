package edu.java.bot.user;

public enum UserState {
    NONE,
    AWAITING_LINK,
    AWAITING_UNTRACK_LINK

}
